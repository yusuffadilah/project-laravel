@extends('template.header')
@extends('template.navbarAdmin')
{{-- 
<div class="row" style="margin-top: 15px;">
    <div class="col-lg-12">

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#jurusan">Tambah Tiket</a>
            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Jurusan</h6>
                </div>

                <div class="card-body">

                    <div class="table-responsive">

                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Nama tiket</th>
                                    <th>Deskripsi </th>
                                    <th>Nama Konser</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Nama Tiket</td>
                                    <td>Deskripsi </td>
                                    <td>nama Konser</td>
                                    <td>
                                        <a href="#" class="badge badge-success">edit</a>
                                        <a href="#" class="badge badge-danger"
                                            onclick="return confirm('yakin menghapus?');">Hapus</a>
                                    </td>

                                </tr>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Nama tiket</th>
                                    <th>Deskripsi </th>
                                    <th>Nama Konser</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

</div>
<!-- End of Main Content -->

<div class="modal fade" id="jurusan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Jurusan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="#>" enctype="multipart/form-data" method="POST">
                    <div class="form-group">
                        <!-- <input type="hiden" name="idj" id="idj"> -->
                        <input class="form-control namaUniv" type="text" required name="nama tiket" id="namatiket"
                            placeholder="Nama tiket">
                    </div>

                    <div class="form-group">
                        <textarea name="deskripsiJ" required placeholder="Deskripsi" id="deskripsi" class="form-control" rows="3"></textarea>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah Tiket</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> --}}

@extends('template.footerAdmin')
