@extends('template.header')

@include('template.navbar')

<section id="beranda" class="hero d-flex align-items-center">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 d-flex flex-column justify-content-center">
                <h1 data-aos="fade-up">{{ $atas }}</h1>
                <h2 data-aos="fade-up" data-aos-delay="400">Beli tiket lebih mudah Menggunuakan sistem ini belitiket
                </h2>
                <div data-aos="fade-up" data-aos-delay="600">
                    <div class="text-center text-lg-start">
                        <a href="#"
                            class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                            <span>Lihat </span>
                            <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
                <img src="assets1/img/homegambar.png" class="img-fluid" alt="">
            </div>
        </div>
    </div>

</section><!-- End Hero -->



<section id="konser" class="testimonials">

    <div class="container" data-aos="fade-up">

        <header class="section-header">
            <p>Konser</p>
        </header>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="200">
            <div class="swiper-wrapper">

                <div class="swiper-slide">
                    <a href="#b">
                        <div class="testimonial-item">
                            <div class="profile mt-auto">
                                <img src="assets1/img/homegambar.png"
                                    style="width: 500px; height: 200px; max-width: 80%" class="testimonial-img"
                                    alt="">
                                <h3>Nama Konser</h3>
                                <!-- <h4>Ceo &amp; Founder</h4> -->
                            </div>
                            <p style="margin: auto;">
                                Deskripai konser
                                Deskripai konser
                                Deskripai konser
                                Deskripai konser
                                Deskripai konser
                                Deskripai konser
                                Deskripai konser
                            </p>
                            <br>

                            <h1 style="color: black;">Rp. 2.000.000</h1>

                            <a href="konser" class="btn btn-success" type="submit"> Beli Tiket </a>
                        </div>
                    </a>
                </div>


            </div>
            <!-- <div class="swiper-pagination"></div> -->
        </div>

    </div>

</section><!-- End Section -->



@extends('template.footer')
