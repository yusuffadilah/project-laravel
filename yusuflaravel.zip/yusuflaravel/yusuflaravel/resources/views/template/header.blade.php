    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <title>{{ $judul }}</title>
        <meta content="" name="description">

        <meta content="" name="keywords">

        <link
            href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
            rel="stylesheet">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <!-- Vendor CSS Files -->
        <link href="assets1/vendor/aos/aos.css" rel="stylesheet">
        <link href="assets1/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets1/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets1/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
        <link href="assets1/vendor/remixicon/remixicon.css" rel="stylesheet">
        <link href="assets1/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

        <link href="assets1/css/style.css" rel="stylesheet">
    </head>
