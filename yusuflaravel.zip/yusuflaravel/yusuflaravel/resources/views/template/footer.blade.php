   <!-- ======= Footer ======= -->
   <footer id="footer" class="footer">



       <div class="container">
           <div class="copyright">
               &copy; Copyright <strong><span>BeliTiket</span></strong>.
           </div>
           <div class="credits">
               Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
           </div>
       </div>
   </footer><!-- End Footer -->

   <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
           class="bi bi-arrow-up-short"></i></a>
   <script src="assets1/vendor/purecounter/purecounter.js"></script>
   <script src="assets1/vendor/aos/aos.js"></script>
   <script src="assets1/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="assets1/vendor/glightbox/js/glightbox.min.js"></script>
   <script src="assets1/vendor/isotope-layout/isotope.pkgd.min.js"></script>
   <script src="assets1/vendor/swiper/swiper-bundle.min.js"></script>
   <script src="assets1/vendor/php-email-form/validate.js"></script>

   <!-- Template Main JS File -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
       integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
   </script>
   <script src="assets1/js/main.js"></script>

   </body>

   </html>
