@extends('template.navbarAdmin')

@extends('template.footerAdmin')
