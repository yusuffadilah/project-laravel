<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>{{ $judul }}</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets1/favicon.ico" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="assets1/css/styles.css" rel="stylesheet" />

    <!-- Custom fonts for this template-->
    <link href="asset1/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets1/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="assets1/css/login.css" rel="stylesheet">
</head>

<div class="wrapper">
    <div class="sct brand">
        <img style="height: 70%; width: 80%;" src="assets1/img/homegambar.png" alt="gambar" class="img-fluid">
    </div>
    <div class="sct login">
        <form class="user" method="post" action="{{ route('postlogin') }}">
            {{ csrf_field() }}
            <h3>Login</h3>
            <br>
            <input type="email" name="email" placeholder="Email">
            <input type="password" name="password" placeholder="Password">
            <div class="forgot-remember">
                <label class="control control-checkbox">
                    Ingat saya
                    <input type="checkbox" />
                    <div class="control_indicator"></div>
                </label>
                <div class="forgot">
                    {{-- <a href="#">Lupa password?</a> --}}
                </div>
            </div>
            <input type="submit" name="send" value="Masuk">

            <div class="text-center">
                {{-- <a class="small" href="#">Buat akun!</a> --}}
            </div>
            <!-- <p class="text-center">Sign up with<br><i class="fa fa-hand-o-down" aria-hidden="true"></i></p>
        <div class="social-sign">
            <a href="#"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a> -->
    </div>
    </form>
</div>

<script src="assets1/js/sb-admin-2.min.js"></script>
@extends('template.footer')
