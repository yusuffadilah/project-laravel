@extends('template.header')
@extends('template.navbar')
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
        <div class="container">

            <ol>
                <li><a href="/yusuflaravel">Home</a></li>
                <li>Detail Konser</li>
            </ol>
            <h2>Konser</h2>

        </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
        <div class="container">

            <div class="row gy-4">

                <div class="col-lg-8">
                    <div class="portfolio-details">
                        <div class="align-items-center">
                            <div class="swiper-slide">
                                <img src="assets1/img/jurusan.jpg" alt="" width="100%">
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="portfolio-info">
                        <h3>Konser Informasi</h3>
                        <ul>
                            <li><strong>Name</strong>: {{ $nama }}</li>
                            <li><strong>Email</strong>: {{ $nama }}</li>
                            <li><strong>Contact</strong>: {{ $nama }}</li>
                            <li><strong>Website</strong>: <a href="#">Nama Website</a>
                            </li>
                        </ul>
                    </div>

                    <br>

                    <div class="portfolio-info">
                        <a href="#" style="margin: auto " class="btn btn-success">Beli tiket</a>
                    </div>

                </div>

                <div class="row">
                    <div class="col-xl-12 col-md-6 mb-4">
                        <div class="card border-left-indigo shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Deskripsi Konser</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">Selamat Datang di Sistem
                                            Informasi Cerdas Rekomendasi Jurusan</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-xl-12 col-md-6 mb-4">
                        <div class="card border-left-indigo shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Syarat dan Ketentuan Konser</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">Syarat dan ketentuan</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section><!-- End Portfolio Details Section -->

</main><!-- End #main -->
@extends('template.footer')
