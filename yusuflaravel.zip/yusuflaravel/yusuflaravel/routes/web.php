<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('publik', [
        "judul" => "Tiket-Konser",
        "atas" => "Selamat datang di pembelian tiket konser",
    ]);
});

Route::get('/konser', function () {
    return view('konser', [
        "judul" => "Konser",
        "nama" => "Beli Tiket",
    ]);
});
Route::get('/login', function () {
    return view('login', [
        "judul" => "Login",
    ]);
});
Route::get('/admin', function () {
    return view('admin', [
        "judul" => "Administrator",
    ]);
});
Route::get('/tiket', function () {
    return view('tiket', [
        "judul" => "tiket",
    ]);
});
Route::get('/pesanan', function () {
    return view('pesanan', [
        "judul" => "pesanan",
    ]);
});

Route::get('/checkin', function () {
    return view('checkin', [
        "judul" => "checkin",
    ]);
});

Route::post('/psotlogin', 'Login@postlogin')->name('postlogin');
